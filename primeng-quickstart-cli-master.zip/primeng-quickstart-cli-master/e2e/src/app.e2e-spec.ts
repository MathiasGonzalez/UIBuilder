import { AppPage } from './app.po';

describe('primeng-quickstart-cli App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });
});
